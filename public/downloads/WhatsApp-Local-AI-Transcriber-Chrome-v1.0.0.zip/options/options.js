// extension/src/options/options.ts
var form = document.getElementById("settings-form");
var serverUrlInput = document.getElementById("server-url");
var authTokenInput = document.getElementById("auth-token");
var languageSelect = document.getElementById("language");
var autoTranscribeCheckbox = document.getElementById("auto-transcribe");
var updateCheckCheckbox = document.getElementById("update-check");
var saveFeedback = document.getElementById("save-feedback");
var cacheFeedback = document.getElementById("cache-feedback");
var updateFeedback = document.getElementById("update-feedback");
var diagPre = document.getElementById("diagnostics-output");
async function loadState() {
  const summary = await chrome.runtime.sendMessage({ type: "GET_STATUS_SUMMARY" });
  serverUrlInput.value = summary.settings.serverUrl;
  authTokenInput.value = summary.settings.authToken;
  languageSelect.value = summary.settings.language;
  autoTranscribeCheckbox.checked = summary.settings.autoTranscribe;
  updateCheckCheckbox.checked = summary.settings.enableGitHubUpdateCheck;
  diagPre.textContent = JSON.stringify(
    {
      backendHealth: summary.health,
      cachedTranscripts: summary.cacheCount,
      adapterDiagnostics: summary.diagnostics ?? {
        status: "NO_WHATSAPP_TAB_REPORTED_YET",
        note: "Bitte WhatsApp Web \xF6ffnen, damit das interne Medienmodul gepr\xFCft wird."
      }
    },
    null,
    2
  );
}
form.addEventListener("submit", async (ev) => {
  ev.preventDefault();
  saveFeedback.textContent = "Speichere...";
  const currentRes = await chrome.runtime.sendMessage({ type: "GET_SETTINGS" });
  const nextSettings = {
    ...currentRes.settings,
    serverUrl: serverUrlInput.value.trim(),
    authToken: authTokenInput.value.trim(),
    language: languageSelect.value,
    autoTranscribe: autoTranscribeCheckbox.checked,
    enableGitHubUpdateCheck: updateCheckCheckbox.checked
  };
  const result = await chrome.runtime.sendMessage({
    type: "SAVE_SETTINGS",
    settings: nextSettings
  });
  saveFeedback.textContent = result.ok ? "Einstellungen lokal gespeichert." : `Fehler: ${result.error ?? "Ung\xFCltige Eingabe"}`;
});
document.getElementById("check-health-btn")?.addEventListener("click", async () => {
  saveFeedback.textContent = "Pr\xFCfe 127.0.0.1:8765...";
  const res = await chrome.runtime.sendMessage({ type: "CHECK_HEALTH" });
  saveFeedback.textContent = res.health.status === "ok" ? `Verbunden: ${res.health.model} (${res.health.device}/${res.health.computeType})` : `Status: ${res.health.error ?? res.health.status}`;
  await loadState();
});
document.getElementById("clear-cache-btn")?.addEventListener("click", async () => {
  await chrome.runtime.sendMessage({ type: "CLEAR_CACHE" });
  cacheFeedback.textContent = "Alle lokalen Transkripte wurden vollst\xE4ndig gel\xF6scht.";
  await loadState();
});
document.getElementById("refresh-diag-btn")?.addEventListener("click", () => {
  void loadState();
});
document.getElementById("check-update-btn")?.addEventListener("click", async () => {
  updateFeedback.textContent = "Pr\xFCfe GitHub Releases...";
  const res = await chrome.runtime.sendMessage({ type: "CHECK_GITHUB_UPDATE" });
  if (res.updateCheck.error) {
    updateFeedback.textContent = `Hinweis: ${res.updateCheck.error}`;
  } else if (res.updateCheck.updateAvailable) {
    updateFeedback.textContent = `Neue Version v${res.updateCheck.latestVersion} auf GitHub verf\xFCgbar!`;
  } else {
    updateFeedback.textContent = `Aktuell (v${res.updateCheck.currentVersion}).`;
  }
});
void loadState();
