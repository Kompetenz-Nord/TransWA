// extension/src/shared/bridge-protocol.ts
var BRIDGE_CHANNEL = "wa-local-ai-transcriber-v1";
var MAX_BRIDGE_AUDIO_BYTES = 50 * 1024 * 1024;
var MAX_BRIDGE_MESSAGE_ID_LEN = 256;
function isValidRequestId(val) {
  return typeof val === "string" && /^[a-zA-Z0-9_-]{8,64}$/.test(val);
}
function isValidMessageId(val) {
  return typeof val === "string" && val.length > 0 && val.length <= MAX_BRIDGE_MESSAGE_ID_LEN && !/[\r\n\0]/.test(val);
}
function validateContentToMainMessage(data) {
  if (!data || typeof data !== "object") return null;
  const obj = data;
  if (obj.channel !== BRIDGE_CHANNEL || obj.direction !== "content-to-main") return null;
  if (!isValidRequestId(obj.requestId)) return null;
  if (obj.type === "FETCH_VOICE_AUDIO") {
    if (!isValidMessageId(obj.messageId)) return null;
    return {
      channel: BRIDGE_CHANNEL,
      direction: "content-to-main",
      requestId: obj.requestId,
      type: "FETCH_VOICE_AUDIO",
      messageId: obj.messageId
    };
  }
  if (obj.type === "GET_ADAPTER_DIAGNOSTICS" || obj.type === "REINITIALIZE_ADAPTER") {
    return {
      channel: BRIDGE_CHANNEL,
      direction: "content-to-main",
      requestId: obj.requestId,
      type: obj.type
    };
  }
  return null;
}
function isTrustedWhatsAppOrigin(origin) {
  return origin === "https://web.whatsapp.com";
}

// extension/src/shared/crypto.ts
var SENSITIVE_KEY_PATTERN = /^(mediakey|encfilehash|filehash|token|authtoken|authorization|secret|cookie|session|phone|jid|remotejid|participant|directpath)$/i;
function sanitizeDiagnosticValue(value, depth = 0) {
  if (depth > 4) {
    return "[TRUNCATED]";
  }
  if (value === null || value === void 0) {
    return value;
  }
  if (typeof value === "string") {
    if (/^\+?\d{8,15}@(c\.us|s\.whatsapp\.net|lid)$/i.test(value)) {
      return "[REDACTED_JID]";
    }
    return value.length > 512 ? `${value.slice(0, 512)}\u2026` : value;
  }
  if (typeof value === "number" || typeof value === "boolean") {
    return value;
  }
  if (Array.isArray(value)) {
    return value.slice(0, 20).map((item) => sanitizeDiagnosticValue(item, depth + 1));
  }
  if (typeof value === "object") {
    const out = {};
    for (const [key, val] of Object.entries(value)) {
      if (SENSITIVE_KEY_PATTERN.test(key)) {
        out[key] = "[REDACTED]";
      } else {
        out[key] = sanitizeDiagnosticValue(val, depth + 1);
      }
    }
    return out;
  }
  return String(value);
}

// extension/src/injected/whatsapp-internal-media-adapter.ts
var DEFAULT_MAX_RETRIES = 12;
var DEFAULT_RETRY_DELAY_MS = 750;
function createBrowserWARuntimeProvider() {
  return {
    requireModule(moduleName) {
      const win = globalThis;
      if (typeof win.require !== "function") {
        return null;
      }
      try {
        return win.require(moduleName);
      } catch {
        return null;
      }
    },
    getWhatsAppVersion() {
      const win = globalThis;
      if (win.Debug?.VERSION) return String(win.Debug.VERSION);
      try {
        const verMod = win.require?.("WAWebBuildConstants");
        const v = verMod?.VERSION ?? verMod?.default?.VERSION;
        return typeof v === "string" ? v : null;
      } catch {
        return null;
      }
    }
  };
}
function resolveDownloadManager(mod) {
  if (!mod || typeof mod !== "object") return null;
  const record = mod;
  const candidates = [record.downloadManager, record.default, record];
  for (const cand of candidates) {
    if (cand && typeof cand === "object" && (typeof cand.downloadAndMaybeDecrypt === "function" || typeof cand.downloadMedia === "function")) {
      return cand;
    }
  }
  return null;
}
function resolveMsgCollection(mod) {
  if (!mod || typeof mod !== "object") return null;
  const record = mod;
  const candidates = [record.MsgCollection, record.default, record];
  for (const cand of candidates) {
    if (cand && typeof cand === "object" && typeof cand.get === "function") {
      return cand;
    }
  }
  return null;
}
var WhatsAppInternalMediaAdapter = class {
  runtime;
  maxRetries;
  retryDelayMs;
  msgCollection = null;
  downloadManager = null;
  status = "UNINITIALIZED";
  initAttempts = 0;
  lastErrorCode = null;
  lastErrorMessage = null;
  initPromise = null;
  constructor(options = {}) {
    this.runtime = options.runtimeProvider ?? createBrowserWARuntimeProvider();
    this.maxRetries = Math.max(1, options.maxRetries ?? DEFAULT_MAX_RETRIES);
    this.retryDelayMs = Math.max(0, options.retryDelayMs ?? DEFAULT_RETRY_DELAY_MS);
  }
  /**
   * Initializes the internal WhatsApp Web modules (`WAWebMsgCollection` and `WAWebDownloadManager`)
   * with bounded retries to accommodate delayed lazy-loading without enumerating arbitrary modules.
   */
  async initialize() {
    if (this.status === "READY" && this.msgCollection && this.downloadManager) {
      return this.getDiagnostics();
    }
    if (this.initPromise) {
      return this.initPromise;
    }
    this.initPromise = this.runBoundedInit().finally(() => {
      this.initPromise = null;
    });
    return this.initPromise;
  }
  async reinitialize() {
    this.msgCollection = null;
    this.downloadManager = null;
    this.status = "UNINITIALIZED";
    this.initAttempts = 0;
    this.lastErrorCode = null;
    this.lastErrorMessage = null;
    return this.initialize();
  }
  async runBoundedInit() {
    this.status = "INITIALIZING";
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      this.initAttempts = attempt;
      const probe = this.probeInternalModules();
      if (probe.ok) {
        this.status = "READY";
        this.lastErrorCode = null;
        this.lastErrorMessage = null;
        return this.getDiagnostics();
      }
      this.status = attempt < this.maxRetries ? "MODULES_DELAYED" : probe.failureStatus;
      this.lastErrorCode = probe.errorCode;
      this.lastErrorMessage = probe.errorMessage;
      if (attempt < this.maxRetries && this.retryDelayMs > 0) {
        await new Promise((resolve) => setTimeout(resolve, this.retryDelayMs));
      }
    }
    return this.getDiagnostics();
  }
  probeInternalModules() {
    const rawMsgMod = this.runtime.requireModule("WAWebMsgCollection");
    const rawDlMod = this.runtime.requireModule("WAWebDownloadManager");
    const msgCollection = resolveMsgCollection(rawMsgMod);
    const downloadManager = resolveDownloadManager(rawDlMod);
    if (!rawMsgMod && !rawDlMod) {
      return {
        ok: false,
        failureStatus: "MODULES_MISSING",
        errorCode: "WA_MODULES_NOT_FOUND",
        errorMessage: "WAWebMsgCollection und WAWebDownloadManager wurden nicht gefunden (WhatsApp Web m\xF6glicherweise noch nicht geladen oder Modulnamen ge\xE4ndert)."
      };
    }
    if (!rawMsgMod) {
      return {
        ok: false,
        failureStatus: "MODULES_MISSING",
        errorCode: "WA_MSG_COLLECTION_MISSING",
        errorMessage: "Internes Modul WAWebMsgCollection nicht verf\xFCgbar."
      };
    }
    if (!rawDlMod) {
      return {
        ok: false,
        failureStatus: "MODULES_MISSING",
        errorCode: "WA_DOWNLOAD_MANAGER_MISSING",
        errorMessage: "Internes Modul WAWebDownloadManager nicht verf\xFCgbar."
      };
    }
    if (!msgCollection || typeof msgCollection.get !== "function") {
      return {
        ok: false,
        failureStatus: "SIGNATURE_MISMATCH",
        errorCode: "WA_MSG_COLLECTION_SIGNATURE_MISMATCH",
        errorMessage: "WAWebMsgCollection bietet keine kompatible .get(id)-Signatur."
      };
    }
    if (!downloadManager || typeof downloadManager.downloadAndMaybeDecrypt !== "function" && typeof downloadManager.downloadMedia !== "function") {
      return {
        ok: false,
        failureStatus: "SIGNATURE_MISMATCH",
        errorCode: "WA_DOWNLOAD_MANAGER_SIGNATURE_MISMATCH",
        errorMessage: "WAWebDownloadManager bietet weder downloadAndMaybeDecrypt noch downloadMedia."
      };
    }
    this.msgCollection = msgCollection;
    this.downloadManager = downloadManager;
    return { ok: true };
  }
  getDiagnostics() {
    const msgGetOk = Boolean(this.msgCollection && typeof this.msgCollection.get === "function");
    const dlSigOk = Boolean(
      this.downloadManager && (typeof this.downloadManager.downloadAndMaybeDecrypt === "function" || typeof this.downloadManager.downloadMedia === "function")
    );
    const rawReport = {
      status: this.status,
      whatsappVersion: this.runtime.getWhatsAppVersion?.() ?? null,
      msgCollectionFound: Boolean(this.msgCollection),
      downloadManagerFound: Boolean(this.downloadManager),
      msgGetSignatureOk: msgGetOk,
      downloadSignatureOk: dlSigOk,
      initAttempts: this.initAttempts,
      maxRetries: this.maxRetries,
      lastErrorCode: this.lastErrorCode,
      lastErrorMessage: this.lastErrorMessage,
      checkedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    return sanitizeDiagnosticValue(rawReport);
  }
  /**
   * Retrieves and decrypts a WhatsApp voice message purely via the active session's
   * internal media modules without triggering HTML audio playback or modifying read state.
   */
  async fetchAndDecryptVoiceMessage(messageId) {
    if (this.status !== "READY" || !this.msgCollection || !this.downloadManager) {
      const diag = await this.initialize();
      if (diag.status !== "READY" || !this.msgCollection || !this.downloadManager) {
        throw new Error(
          `[${diag.lastErrorCode ?? "ADAPTER_NOT_READY"}] ${diag.lastErrorMessage ?? "WhatsApp-Medienmodule nicht bereit."}`
        );
      }
    }
    const msg = this.lookupMessage(messageId);
    if (!msg) {
      throw new Error(
        `[MSG_NOT_FOUND] Nachricht "${messageId}" wurde in WAWebMsgCollection nicht gefunden.`
      );
    }
    const mediaParams = this.extractMediaParams(messageId, msg);
    if (!mediaParams.type || mediaParams.type !== "ptt" && mediaParams.type !== "audio") {
      throw new Error(
        `[NOT_AUDIO_MESSAGE] Nachricht "${messageId}" hat Typ "${mediaParams.type ?? "unbekannt"}".`
      );
    }
    if (!mediaParams.directPath || !mediaParams.mediaKey || !mediaParams.encFilehash || !mediaParams.filehash) {
      throw new Error(
        `[INCOMPLETE_MEDIA_METADATA] Erforderliche Mediendaten (directPath/mediaKey/hashes) fehlen f\xFCr "${messageId}".`
      );
    }
    const rawBuffer = await this.invokeInternalDownload(mediaParams);
    const arrayBuffer = await this.normalizeToArrayBuffer(rawBuffer);
    if (arrayBuffer.byteLength === 0) {
      throw new Error(`[EMPTY_AUDIO_BUFFER] Entschl\xFCsselter Audiopuffer f\xFCr "${messageId}" ist leer.`);
    }
    const metadata = {
      messageId,
      direction: mediaParams.direction,
      type: mediaParams.type,
      mimetype: mediaParams.mimetype,
      durationSec: mediaParams.durationSec,
      hasDirectPath: true,
      hasEncFilehash: true,
      hasFilehash: true,
      hasMediaKey: true,
      mediaKeyTimestamp: mediaParams.mediaKeyTimestamp
    };
    return {
      messageId,
      direction: mediaParams.direction,
      mimetype: mediaParams.mimetype,
      durationSec: mediaParams.durationSec,
      byteLength: arrayBuffer.byteLength,
      buffer: arrayBuffer,
      metadata
    };
  }
  lookupMessage(messageId) {
    if (!this.msgCollection) return void 0;
    const direct = this.msgCollection.get?.(messageId);
    if (direct) return direct;
    if (typeof this.msgCollection.getModelsArray === "function") {
      const models = this.msgCollection.getModelsArray();
      const targetSuffix = messageId.split("_").pop();
      return models.find((m) => {
        const serialized = typeof m.id === "string" ? m.id : m.id?._serialized ?? m.id?.id ?? "";
        return serialized === messageId || targetSuffix && serialized.endsWith(`_${targetSuffix}`);
      });
    }
    return void 0;
  }
  extractMediaParams(messageId, msg) {
    const mediaSource = msg.mediaObject ?? msg.mediaData ?? msg;
    const directPath = mediaSource.directPath ?? msg.directPath ?? "";
    const encFilehash = mediaSource.encFilehash ?? msg.encFilehash ?? "";
    const filehash = mediaSource.filehash ?? msg.filehash ?? "";
    const mediaKey = mediaSource.mediaKey ?? msg.mediaKey ?? "";
    const mediaKeyTimestamp = typeof (mediaSource.mediaKeyTimestamp ?? msg.mediaKeyTimestamp) === "number" ? mediaSource.mediaKeyTimestamp ?? msg.mediaKeyTimestamp ?? null : null;
    const type = String(msg.type ?? mediaSource.type ?? "ptt");
    const mimetype = String(msg.mimetype ?? mediaSource.mimetype ?? "audio/ogg; codecs=opus");
    const durationSec = typeof msg.duration === "number" ? msg.duration : null;
    const isFromMe = typeof msg.isFromMe === "boolean" ? msg.isFromMe : typeof msg.fromMe === "boolean" ? msg.fromMe : typeof msg.id === "object" && typeof msg.id?.fromMe === "boolean" ? msg.id.fromMe : messageId.startsWith("true_");
    return {
      directPath,
      encFilehash,
      filehash,
      mediaKey,
      mediaKeyTimestamp,
      type,
      mimetype,
      durationSec,
      direction: isFromMe ? "outgoing" : "incoming"
    };
  }
  async invokeInternalDownload(params) {
    if (!this.downloadManager) {
      throw new Error("[ADAPTER_NOT_READY] WAWebDownloadManager fehlt.");
    }
    const requestPayload = {
      directPath: params.directPath,
      encFilehash: params.encFilehash,
      filehash: params.filehash,
      mediaKey: params.mediaKey,
      mediaKeyTimestamp: params.mediaKeyTimestamp ?? Math.floor(Date.now() / 1e3),
      type: params.type,
      signal: void 0,
      userDownloadAttemptCount: 0,
      isUserInitiated: false
    };
    if (typeof this.downloadManager.downloadAndMaybeDecrypt === "function") {
      return this.downloadManager.downloadAndMaybeDecrypt(requestPayload);
    }
    if (typeof this.downloadManager.downloadMedia === "function") {
      return this.downloadManager.downloadMedia(requestPayload);
    }
    throw new Error("[WA_DOWNLOAD_MANAGER_SIGNATURE_MISMATCH] Keine kompatible Download-Methode gefunden.");
  }
  async normalizeToArrayBuffer(raw) {
    if (raw instanceof ArrayBuffer) {
      return raw;
    }
    if (ArrayBuffer.isView(raw)) {
      const view = new Uint8Array(raw.buffer, raw.byteOffset, raw.byteLength);
      const copy = new Uint8Array(view.byteLength);
      copy.set(view);
      return copy.buffer;
    }
    if (typeof Blob !== "undefined" && raw instanceof Blob) {
      return raw.arrayBuffer();
    }
    if (raw && typeof raw === "object" && "buffer" in raw) {
      const nested = raw.buffer;
      if (nested instanceof ArrayBuffer) return nested;
    }
    throw new Error("[UNSUPPORTED_MEDIA_RETURN] Unerwartetes R\xFCckgabeformat beim Medienabruf.");
  }
};

// extension/src/injected/main-world.ts
var adapter = new WhatsAppInternalMediaAdapter({
  maxRetries: 12,
  retryDelayMs: 750
});
function postToContentScript(payload, transferables = []) {
  if (!isTrustedWhatsAppOrigin(window.location.origin)) return;
  window.postMessage(payload, window.location.origin, transferables);
}
window.addEventListener("message", async (event) => {
  if (event.source !== window) return;
  if (!isTrustedWhatsAppOrigin(event.origin)) return;
  const validated = validateContentToMainMessage(event.data);
  if (!validated) return;
  if (validated.type === "GET_ADAPTER_DIAGNOSTICS") {
    const report = adapter.getDiagnostics();
    postToContentScript({
      channel: BRIDGE_CHANNEL,
      direction: "main-to-content",
      requestId: validated.requestId,
      type: "ADAPTER_DIAGNOSTICS_RESULT",
      report
    });
    return;
  }
  if (validated.type === "REINITIALIZE_ADAPTER") {
    const report = await adapter.reinitialize();
    postToContentScript({
      channel: BRIDGE_CHANNEL,
      direction: "main-to-content",
      requestId: validated.requestId,
      type: "ADAPTER_DIAGNOSTICS_RESULT",
      report
    });
    return;
  }
  if (validated.type === "FETCH_VOICE_AUDIO") {
    try {
      const result = await adapter.fetchAndDecryptVoiceMessage(validated.messageId);
      postToContentScript(
        {
          channel: BRIDGE_CHANNEL,
          direction: "main-to-content",
          requestId: validated.requestId,
          type: "VOICE_AUDIO_RESULT",
          ok: true,
          messageId: result.messageId,
          voiceDirection: result.direction,
          mimetype: result.mimetype,
          durationSec: result.durationSec,
          buffer: result.buffer,
          metadata: result.metadata
        },
        [result.buffer]
      );
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Medienabruf fehlgeschlagen";
      const codeMatch = /^\[([A-Z0-9_]+)\]\s*(.*)$/.exec(msg);
      postToContentScript({
        channel: BRIDGE_CHANNEL,
        direction: "main-to-content",
        requestId: validated.requestId,
        type: "VOICE_AUDIO_RESULT",
        ok: false,
        messageId: validated.messageId,
        errorCode: codeMatch?.[1] ?? "MEDIA_FETCH_ERROR",
        errorMessage: codeMatch?.[2] ?? msg
      });
    }
  }
});
void adapter.initialize().then((report) => {
  postToContentScript({
    channel: BRIDGE_CHANNEL,
    direction: "main-to-content",
    requestId: "init_status_event",
    type: "ADAPTER_STATUS_EVENT",
    report
  });
});
