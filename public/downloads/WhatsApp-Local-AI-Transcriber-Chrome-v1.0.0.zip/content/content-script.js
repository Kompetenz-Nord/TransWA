// extension/src/shared/bridge-protocol.ts
var BRIDGE_CHANNEL = "wa-local-ai-transcriber-v1";
var MAX_BRIDGE_AUDIO_BYTES = 50 * 1024 * 1024;
var MAX_BRIDGE_MESSAGE_ID_LEN = 256;
function isValidRequestId(val) {
  return typeof val === "string" && /^[a-zA-Z0-9_-]{8,64}$/.test(val);
}
function isValidMessageId(val) {
  return typeof val === "string" && val.length > 0 && val.length <= MAX_BRIDGE_MESSAGE_ID_LEN && !/[\r\n\0]/.test(val);
}
function validateMainToContentMessage(data) {
  if (!data || typeof data !== "object") return null;
  const obj = data;
  if (obj.channel !== BRIDGE_CHANNEL || obj.direction !== "main-to-content") return null;
  if (!isValidRequestId(obj.requestId)) return null;
  if (obj.type === "VOICE_AUDIO_RESULT") {
    if (!isValidMessageId(obj.messageId)) return null;
    if (obj.ok === true) {
      if (!(obj.buffer instanceof ArrayBuffer)) return null;
      if (obj.buffer.byteLength === 0 || obj.buffer.byteLength > MAX_BRIDGE_AUDIO_BYTES) {
        return null;
      }
      if (typeof obj.mimetype !== "string" || obj.mimetype.length > 120) return null;
      if (obj.voiceDirection !== "incoming" && obj.voiceDirection !== "outgoing") return null;
      if (!obj.metadata || typeof obj.metadata !== "object") return null;
      return data;
    }
    if (obj.ok === false) {
      if (typeof obj.errorCode !== "string" || typeof obj.errorMessage !== "string") return null;
      return {
        channel: BRIDGE_CHANNEL,
        direction: "main-to-content",
        requestId: obj.requestId,
        type: "VOICE_AUDIO_RESULT",
        ok: false,
        messageId: obj.messageId,
        errorCode: obj.errorCode.slice(0, 80),
        errorMessage: obj.errorMessage.slice(0, 300)
      };
    }
    return null;
  }
  if (obj.type === "ADAPTER_DIAGNOSTICS_RESULT" || obj.type === "ADAPTER_STATUS_EVENT") {
    if (!obj.report || typeof obj.report !== "object") return null;
    return data;
  }
  return null;
}
function isTrustedWhatsAppOrigin(origin) {
  return origin === "https://web.whatsapp.com";
}

// extension/src/shared/cache.ts
var ChromeStorageAdapter = class {
  async getItem(key) {
    const result = await chrome.storage.local.get(key);
    const val = result[key];
    return typeof val === "string" ? val : null;
  }
  async setItem(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }
  async removeItem(key) {
    await chrome.storage.local.remove(key);
  }
};
var CACHE_STORAGE_KEY = "wa_local_ai_transcript_cache_v1";
var MAX_CACHED_RECORDS = 2e3;
var LocalTranscriptCache = class {
  storage;
  loaded = false;
  data = {
    version: 1,
    byMessageId: {},
    byAudioHash: {}
  };
  constructor(storage) {
    this.storage = storage;
  }
  async ensureLoaded() {
    if (this.loaded) return;
    try {
      const raw = await this.storage.getItem(CACHE_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.version === 1 && parsed.byMessageId && parsed.byAudioHash) {
          this.data = {
            version: 1,
            byMessageId: parsed.byMessageId,
            byAudioHash: parsed.byAudioHash
          };
        }
      }
    } catch {
      this.data = { version: 1, byMessageId: {}, byAudioHash: {} };
    }
    this.loaded = true;
  }
  async getByMessageId(messageId) {
    await this.ensureLoaded();
    return this.data.byMessageId[messageId] ?? null;
  }
  async getByAudioHash(audioHash) {
    await this.ensureLoaded();
    const mappedId = this.data.byAudioHash[audioHash];
    if (!mappedId) return null;
    return this.data.byMessageId[mappedId] ?? null;
  }
  async put(record) {
    await this.ensureLoaded();
    const cleanRecord = {
      messageId: record.messageId,
      audioHash: record.audioHash,
      transcript: record.transcript,
      language: record.language,
      status: record.status,
      modelVersion: record.modelVersion,
      processedAt: record.processedAt,
      durationSec: record.durationSec,
      inferenceDevice: record.inferenceDevice
    };
    this.data.byMessageId[cleanRecord.messageId] = cleanRecord;
    if (cleanRecord.audioHash) {
      this.data.byAudioHash[cleanRecord.audioHash] = cleanRecord.messageId;
    }
    this.evictOldestIfNeeded();
    await this.persist();
  }
  async deleteByMessageId(messageId) {
    await this.ensureLoaded();
    const existing = this.data.byMessageId[messageId];
    if (existing?.audioHash && this.data.byAudioHash[existing.audioHash] === messageId) {
      delete this.data.byAudioHash[existing.audioHash];
    }
    delete this.data.byMessageId[messageId];
    await this.persist();
  }
  async clearAll() {
    this.data = { version: 1, byMessageId: {}, byAudioHash: {} };
    this.loaded = true;
    await this.storage.removeItem(CACHE_STORAGE_KEY);
  }
  async count() {
    await this.ensureLoaded();
    return Object.keys(this.data.byMessageId).length;
  }
  async listAll() {
    await this.ensureLoaded();
    return Object.values(this.data.byMessageId).sort(
      (a, b) => b.processedAt.localeCompare(a.processedAt)
    );
  }
  evictOldestIfNeeded() {
    const entries = Object.entries(this.data.byMessageId);
    if (entries.length <= MAX_CACHED_RECORDS) return;
    entries.sort((a, b) => a[1].processedAt.localeCompare(b[1].processedAt));
    const toRemove = entries.length - MAX_CACHED_RECORDS;
    for (let i = 0; i < toRemove; i++) {
      const [msgId, rec] = entries[i];
      delete this.data.byMessageId[msgId];
      if (rec.audioHash && this.data.byAudioHash[rec.audioHash] === msgId) {
        delete this.data.byAudioHash[rec.audioHash];
      }
    }
  }
  async persist() {
    await this.storage.setItem(CACHE_STORAGE_KEY, JSON.stringify(this.data));
  }
};

// extension/src/shared/crypto.ts
async function sha256Hex(input) {
  const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  const digest = await globalThis.crypto.subtle.digest("SHA-256", copy.buffer);
  const view = new Uint8Array(digest);
  let hex = "";
  for (let i = 0; i < view.length; i++) {
    hex += view[i].toString(16).padStart(2, "0");
  }
  return hex;
}

// extension/src/shared/types.ts
var DEFAULT_EXTENSION_SETTINGS = {
  serverUrl: "http://127.0.0.1:8765",
  authToken: "",
  language: "auto",
  autoTranscribe: true,
  showTranscriptExpandedByDefault: true,
  enableGitHubUpdateCheck: true,
  githubRepo: "SmartSolarium/whatsapp-business-local-ai-transcriber"
};
var WHISPER_MODEL_ID = "Systran/faster-whisper-small";

// extension/src/shared/queue.ts
var TranscriptionQueue = class {
  cache;
  fetcher;
  transcriber;
  concurrency;
  pendingIds = [];
  activeIds = /* @__PURE__ */ new Set();
  processedOrQueuedIds = /* @__PURE__ */ new Set();
  jobs = /* @__PURE__ */ new Map();
  listeners = /* @__PURE__ */ new Set();
  constructor(options) {
    this.cache = options.cache;
    this.fetcher = options.fetcher;
    this.transcriber = options.transcriber;
    this.concurrency = Math.max(1, options.concurrency ?? 1);
  }
  subscribe(listener) {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }
  getJob(messageId) {
    return this.jobs.get(messageId);
  }
  getStats() {
    return {
      queued: this.pendingIds.length,
      active: this.activeIds.size,
      totalTracked: this.jobs.size
    };
  }
  async enqueue(messageId, direction, forceRetry = false) {
    if (!forceRetry && this.processedOrQueuedIds.has(messageId)) {
      const existing = this.jobs.get(messageId);
      if (existing) return existing;
    }
    if (!forceRetry) {
      const cached = await this.cache.getByMessageId(messageId);
      if (cached && cached.status === "completed") {
        const job = {
          messageId,
          direction,
          status: "cached",
          transcript: cached.transcript,
          language: cached.language,
          audioHash: cached.audioHash,
          modelVersion: cached.modelVersion,
          errorMessage: null,
          fromCache: true,
          updatedAt: cached.processedAt,
          inferenceDevice: cached.inferenceDevice
        };
        this.processedOrQueuedIds.add(messageId);
        this.jobs.set(messageId, job);
        this.emit(job);
        return job;
      }
    }
    this.processedOrQueuedIds.add(messageId);
    const queuedJob = {
      messageId,
      direction,
      status: "queued",
      transcript: null,
      language: null,
      audioHash: null,
      modelVersion: WHISPER_MODEL_ID,
      errorMessage: null,
      fromCache: false,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    this.jobs.set(messageId, queuedJob);
    this.emit(queuedJob);
    if (!this.pendingIds.includes(messageId) && !this.activeIds.has(messageId)) {
      this.pendingIds.push(messageId);
    }
    void this.pump();
    return queuedJob;
  }
  async pump() {
    while (this.activeIds.size < this.concurrency && this.pendingIds.length > 0) {
      const nextId = this.pendingIds.shift();
      if (!nextId) break;
      this.activeIds.add(nextId);
      void this.processJob(nextId).finally(() => {
        this.activeIds.delete(nextId);
        void this.pump();
      });
    }
  }
  async processJob(messageId) {
    const existing = this.jobs.get(messageId);
    if (!existing) return;
    try {
      this.updateJob(messageId, { status: "fetching_media", errorMessage: null });
      const audio = await this.fetcher.fetchVoiceAudio(messageId);
      const audioHash = await sha256Hex(audio.buffer);
      const cachedByHash = await this.cache.getByAudioHash(audioHash);
      if (cachedByHash && cachedByHash.status === "completed") {
        await this.cache.put({
          ...cachedByHash,
          messageId,
          processedAt: (/* @__PURE__ */ new Date()).toISOString()
        });
        this.updateJob(messageId, {
          status: "cached",
          transcript: cachedByHash.transcript,
          language: cachedByHash.language,
          audioHash,
          modelVersion: cachedByHash.modelVersion,
          fromCache: true,
          inferenceDevice: cachedByHash.inferenceDevice
        });
        return;
      }
      this.updateJob(messageId, {
        status: "transcribing",
        audioHash,
        direction: audio.direction
      });
      const result = await this.transcriber.transcribe({
        audioBuffer: audio.buffer,
        mimetype: audio.mimetype,
        audioHash,
        messageId
      });
      const now = (/* @__PURE__ */ new Date()).toISOString();
      const modelVersion = result.modelVersion ?? WHISPER_MODEL_ID;
      await this.cache.put({
        messageId,
        audioHash,
        transcript: result.transcript,
        language: result.language,
        status: "completed",
        modelVersion,
        processedAt: now,
        durationSec: audio.durationSec,
        inferenceDevice: result.inferenceDevice
      });
      this.updateJob(messageId, {
        status: "completed",
        transcript: result.transcript,
        language: result.language,
        audioHash,
        modelVersion,
        errorMessage: null,
        fromCache: false,
        updatedAt: now,
        inferenceDevice: result.inferenceDevice
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unbekannter Transkriptionsfehler";
      this.updateJob(messageId, {
        status: "error",
        errorMessage: msg,
        updatedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    }
  }
  updateJob(messageId, patch) {
    const current = this.jobs.get(messageId);
    if (!current) return;
    const next = {
      ...current,
      ...patch,
      updatedAt: patch.updatedAt ?? (/* @__PURE__ */ new Date()).toISOString()
    };
    this.jobs.set(messageId, next);
    this.emit(next);
  }
  emit(job) {
    for (const listener of this.listeners) {
      try {
        listener(job);
      } catch {
      }
    }
  }
  clearTrackedJobs() {
    this.pendingIds.length = 0;
    this.processedOrQueuedIds.clear();
    this.jobs.clear();
  }
};

// extension/src/content/dom-observer.ts
var VOICE_ICON_SELECTORS = [
  '[data-icon="audio-play"]',
  '[data-icon="ptt-play"]',
  '[data-icon="audio-pause"]',
  '[data-icon="ptt-pause"]',
  '[data-testid="ptt-player"]',
  '[data-testid="audio-player"]',
  'span[aria-label*="Sprachnachricht" i]',
  'span[aria-label*="Voice message" i]',
  'button[aria-label*="Sprachnachricht" i]',
  'button[aria-label*="Voice message" i]'
];
var TRANSCRIPT_CONTAINER_ATTR = "data-wa-local-ai-transcript";
function detectVoiceMessageDirection(messageEl, messageId) {
  if (messageEl.classList.contains("message-out") || messageEl.closest(".message-out")) {
    return "outgoing";
  }
  if (messageEl.classList.contains("message-in") || messageEl.closest(".message-in")) {
    return "incoming";
  }
  return messageId.startsWith("true_") ? "outgoing" : "incoming";
}
function findVoiceMessagesInRoot(root) {
  const results = [];
  const seenIds = /* @__PURE__ */ new Set();
  const candidates = root.querySelectorAll("[data-id]");
  for (const el of Array.from(candidates)) {
    const messageId = el.getAttribute("data-id")?.trim();
    if (!messageId || seenIds.has(messageId)) continue;
    if (!/^(true|false)_/.test(messageId)) continue;
    const hasVoiceMarker = VOICE_ICON_SELECTORS.some((sel) => el.querySelector(sel) !== null);
    if (!hasVoiceMarker) continue;
    seenIds.add(messageId);
    results.push({
      messageId,
      direction: detectVoiceMessageDirection(el, messageId),
      element: el
    });
  }
  return results;
}
function isWhatsAppDarkTheme(doc) {
  const body = doc.body;
  const html = doc.documentElement;
  if (body?.classList.contains("dark") || html?.classList.contains("dark")) {
    return true;
  }
  if (body?.getAttribute("data-theme") === "dark" || html?.getAttribute("data-theme") === "dark") {
    return true;
  }
  return false;
}
function renderTranscriptIntoMessageElement(doc, messageEl, job, actions) {
  const existing = messageEl.querySelector(`[${TRANSCRIPT_CONTAINER_ATTR}]`);
  const container = existing ?? doc.createElement("div");
  const isCollapsed = container.getAttribute("data-collapsed") === "true";
  if (!existing) {
    container.setAttribute(TRANSCRIPT_CONTAINER_ATTR, job.messageId);
    container.className = "wa-local-ai-transcript-box";
    const anchorTarget = messageEl.querySelector('[data-testid="ptt-player"]')?.parentElement ?? messageEl.querySelector('[data-testid="audio-player"]')?.parentElement ?? messageEl;
    anchorTarget.appendChild(container);
  }
  container.setAttribute("data-status", job.status);
  container.setAttribute("data-theme", isWhatsAppDarkTheme(doc) ? "dark" : "light");
  while (container.firstChild) {
    container.removeChild(container.firstChild);
  }
  const header = doc.createElement("div");
  header.className = "wa-local-ai-header";
  const titleGroup = doc.createElement("div");
  titleGroup.className = "wa-local-ai-title-group";
  const titleEl = doc.createElement("strong");
  titleEl.className = "wa-local-ai-title";
  titleEl.textContent = "Transkript";
  titleGroup.appendChild(titleEl);
  const statusMeta = doc.createElement("span");
  statusMeta.className = "wa-local-ai-meta";
  statusMeta.textContent = formatStatusMeta(job);
  titleGroup.appendChild(statusMeta);
  header.appendChild(titleGroup);
  const controls = doc.createElement("div");
  controls.className = "wa-local-ai-controls";
  if (job.transcript && (job.status === "completed" || job.status === "cached")) {
    const copyBtn = doc.createElement("button");
    copyBtn.type = "button";
    copyBtn.className = "wa-local-ai-btn";
    copyBtn.textContent = "Kopieren";
    copyBtn.setAttribute("aria-label", "Transkript kopieren");
    copyBtn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      if (actions.onCopy) {
        actions.onCopy(job.transcript ?? "");
      } else if (doc.defaultView?.navigator?.clipboard) {
        void doc.defaultView.navigator.clipboard.writeText(job.transcript ?? "");
      }
      copyBtn.textContent = "Kopiert";
      setTimeout(() => {
        copyBtn.textContent = "Kopieren";
      }, 1500);
    });
    controls.appendChild(copyBtn);
    const toggleBtn = doc.createElement("button");
    toggleBtn.type = "button";
    toggleBtn.className = "wa-local-ai-btn";
    toggleBtn.textContent = isCollapsed ? "Einblenden" : "Ausblenden";
    toggleBtn.setAttribute("aria-expanded", String(!isCollapsed));
    toggleBtn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const nextCollapsed = container.getAttribute("data-collapsed") !== "true";
      container.setAttribute("data-collapsed", String(nextCollapsed));
      renderTranscriptIntoMessageElement(doc, messageEl, job, actions);
    });
    controls.appendChild(toggleBtn);
  }
  if (job.status === "error") {
    const retryBtn = doc.createElement("button");
    retryBtn.type = "button";
    retryBtn.className = "wa-local-ai-btn wa-local-ai-btn-retry";
    retryBtn.textContent = "Erneut versuchen";
    retryBtn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      actions.onRetry(job.messageId);
    });
    controls.appendChild(retryBtn);
  }
  header.appendChild(controls);
  container.appendChild(header);
  if (!isCollapsed) {
    const body = doc.createElement("div");
    body.className = "wa-local-ai-body";
    if (job.status === "completed" || job.status === "cached") {
      const p = doc.createElement("p");
      p.className = "wa-local-ai-text";
      p.textContent = job.transcript || "(Kein gesprochener Text erkannt)";
      body.appendChild(p);
    } else if (job.status === "error") {
      const errP = doc.createElement("p");
      errP.className = "wa-local-ai-error";
      errP.textContent = job.errorMessage ?? "Transkription fehlgeschlagen.";
      body.appendChild(errP);
    } else {
      const progressP = doc.createElement("p");
      progressP.className = "wa-local-ai-pending";
      progressP.textContent = job.status === "queued" ? "Wartet in lokaler Warteschlange..." : job.status === "fetching_media" ? "Rufe entschl\xFCsseltes Audio \xFCber WhatsApp-Modul ab..." : "Transkribiere lokal mit Whisper Small...";
      body.appendChild(progressP);
    }
    container.appendChild(body);
  }
  return container;
}
function formatStatusMeta(job) {
  const parts = [];
  if (job.status === "cached") {
    parts.push("Aus lokalem Cache");
  } else if (job.status === "completed") {
    parts.push("Lokal (Whisper Small)");
  } else if (job.status === "transcribing") {
    parts.push("Verarbeitung...");
  } else if (job.status === "fetching_media") {
    parts.push("Medienabruf...");
  } else if (job.status === "queued") {
    parts.push("Warteschlange");
  } else if (job.status === "error") {
    parts.push("Fehler");
  }
  if (job.language) {
    parts.push(job.language.toUpperCase());
  }
  if (job.inferenceDevice) {
    parts.push(job.inferenceDevice);
  }
  return parts.join(" \xB7 ");
}

// extension/src/content/content-script.ts
var pendingBridgeRequests = /* @__PURE__ */ new Map();
var messageElementRegistry = /* @__PURE__ */ new Map();
var latestAdapterDiagnostics = null;
var currentSettings = { ...DEFAULT_EXTENSION_SETTINGS };
function createRequestId() {
  const rand = globalThis.crypto.getRandomValues(new Uint8Array(12));
  return Array.from(rand, (b) => b.toString(16).padStart(2, "0")).join("");
}
function sendBridgeRequest(payloadBuilder, timeoutMs = 25e3) {
  if (!isTrustedWhatsAppOrigin(window.location.origin)) {
    return Promise.reject(new Error("Nicht vertrauensw\xFCrdiger Ursprung f\xFCr WhatsApp-Br\xFCcke."));
  }
  const requestId = createRequestId();
  const payload = payloadBuilder(requestId);
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      pendingBridgeRequests.delete(requestId);
      reject(new Error("Zeit\xFCberschreitung bei Kommunikation mit dem WhatsApp-Medienmodul."));
    }, timeoutMs);
    pendingBridgeRequests.set(requestId, {
      resolve,
      reject,
      timer
    });
    window.postMessage(payload, window.location.origin);
  });
}
window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  if (!isTrustedWhatsAppOrigin(event.origin)) return;
  const validated = validateMainToContentMessage(event.data);
  if (!validated) return;
  if (validated.type === "ADAPTER_STATUS_EVENT") {
    latestAdapterDiagnostics = validated.report;
    void chrome.runtime.sendMessage({
      type: "UPDATE_ADAPTER_DIAGNOSTICS",
      report: validated.report
    });
    return;
  }
  const pending = pendingBridgeRequests.get(validated.requestId);
  if (!pending) return;
  clearTimeout(pending.timer);
  pendingBridgeRequests.delete(validated.requestId);
  if (validated.type === "ADAPTER_DIAGNOSTICS_RESULT") {
    latestAdapterDiagnostics = validated.report;
    pending.resolve(validated.report);
    return;
  }
  if (validated.type === "VOICE_AUDIO_RESULT") {
    if (validated.ok) {
      const result = {
        messageId: validated.messageId,
        direction: validated.voiceDirection,
        mimetype: validated.mimetype,
        durationSec: validated.durationSec,
        byteLength: validated.buffer.byteLength,
        buffer: validated.buffer,
        metadata: validated.metadata
      };
      pending.resolve(result);
    } else {
      pending.reject(new Error(`[${validated.errorCode}] ${validated.errorMessage}`));
    }
  }
});
var bridgeAudioFetcher = {
  fetchVoiceAudio(messageId) {
    return sendBridgeRequest((requestId) => ({
      channel: BRIDGE_CHANNEL,
      direction: "content-to-main",
      requestId,
      type: "FETCH_VOICE_AUDIO",
      messageId
    }));
  }
};
var serviceWorkerTranscriber = {
  async transcribe(params) {
    const bytes = new Uint8Array(params.audioBuffer);
    let binary = "";
    const chunkSize = 32768;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    const base64Audio = btoa(binary);
    const response = await chrome.runtime.sendMessage({
      type: "TRANSCRIBE_AUDIO",
      payload: {
        messageId: params.messageId,
        audioHash: params.audioHash,
        mimetype: params.mimetype,
        audioBase64: base64Audio
      }
    });
    if (!response || !response.ok) {
      throw new Error(response?.error ?? "Lokaler Whisper-Server nicht erreichbar.");
    }
    return {
      transcript: response.transcript,
      language: response.language,
      inferenceDevice: response.inferenceDevice,
      modelVersion: response.modelVersion
    };
  }
};
var cache = new LocalTranscriptCache(new ChromeStorageAdapter());
var queue = new TranscriptionQueue({
  cache,
  fetcher: bridgeAudioFetcher,
  transcriber: serviceWorkerTranscriber,
  concurrency: 1
});
function syncJobToDOM(job) {
  const el = messageElementRegistry.get(job.messageId);
  if (!el || !el.isConnected) return;
  renderTranscriptIntoMessageElement(document, el, job, {
    onRetry: (id) => {
      void queue.enqueue(id, job.direction, true);
    }
  });
}
queue.subscribe(syncJobToDOM);
async function scanRootForVoiceMessages(root) {
  const detected = findVoiceMessagesInRoot(root);
  for (const item of detected) {
    messageElementRegistry.set(item.messageId, item.element);
    const existingJob = queue.getJob(item.messageId);
    if (existingJob) {
      syncJobToDOM(existingJob);
      continue;
    }
    if (currentSettings.autoTranscribe) {
      await queue.enqueue(item.messageId, item.direction, false);
    } else {
      const cached = await cache.getByMessageId(item.messageId);
      if (cached) {
        await queue.enqueue(item.messageId, item.direction, false);
      }
    }
  }
}
var scanTimer = null;
function scheduleScan() {
  if (scanTimer) return;
  scanTimer = setTimeout(() => {
    scanTimer = null;
    const mainEl = document.querySelector("#main") ?? document.body;
    if (mainEl) {
      void scanRootForVoiceMessages(mainEl);
    }
  }, 180);
}
async function bootstrapContentScript() {
  try {
    const res = await chrome.runtime.sendMessage({ type: "GET_SETTINGS" });
    if (res?.settings) {
      currentSettings = res.settings;
    }
  } catch {
  }
  const observer = new MutationObserver((mutations) => {
    let shouldScan = false;
    for (const m of mutations) {
      if (m.addedNodes.length > 0) {
        shouldScan = true;
        break;
      }
    }
    if (shouldScan) {
      scheduleScan();
    }
  });
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });
  scheduleScan();
}
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const msg = message;
  if (msg?.type === "PING_CONTENT_DIAGNOSTICS") {
    void sendBridgeRequest((requestId) => ({
      channel: BRIDGE_CHANNEL,
      direction: "content-to-main",
      requestId,
      type: "GET_ADAPTER_DIAGNOSTICS"
    })).then((report) => {
      sendResponse({ ok: true, report, queue: queue.getStats() });
    }).catch((err) => {
      sendResponse({
        ok: false,
        report: latestAdapterDiagnostics,
        error: err.message,
        queue: queue.getStats()
      });
    });
    return true;
  }
  if (msg?.type === "CACHE_CLEARED") {
    queue.clearTrackedJobs();
    sendResponse({ ok: true });
    return false;
  }
  return false;
});
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => void bootstrapContentScript());
} else {
  void bootstrapContentScript();
}
