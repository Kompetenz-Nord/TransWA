// extension/src/shared/cache.ts
var ChromeStorageAdapter = class {
  async getItem(key) {
    const result = await chrome.storage.local.get(key);
    const val = result[key];
    return typeof val === "string" ? val : null;
  }
  async setItem(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }
  async removeItem(key) {
    await chrome.storage.local.remove(key);
  }
};
var CACHE_STORAGE_KEY = "wa_local_ai_transcript_cache_v1";
var MAX_CACHED_RECORDS = 2e3;
var LocalTranscriptCache = class {
  storage;
  loaded = false;
  data = {
    version: 1,
    byMessageId: {},
    byAudioHash: {}
  };
  constructor(storage) {
    this.storage = storage;
  }
  async ensureLoaded() {
    if (this.loaded) return;
    try {
      const raw = await this.storage.getItem(CACHE_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.version === 1 && parsed.byMessageId && parsed.byAudioHash) {
          this.data = {
            version: 1,
            byMessageId: parsed.byMessageId,
            byAudioHash: parsed.byAudioHash
          };
        }
      }
    } catch {
      this.data = { version: 1, byMessageId: {}, byAudioHash: {} };
    }
    this.loaded = true;
  }
  async getByMessageId(messageId) {
    await this.ensureLoaded();
    return this.data.byMessageId[messageId] ?? null;
  }
  async getByAudioHash(audioHash) {
    await this.ensureLoaded();
    const mappedId = this.data.byAudioHash[audioHash];
    if (!mappedId) return null;
    return this.data.byMessageId[mappedId] ?? null;
  }
  async put(record) {
    await this.ensureLoaded();
    const cleanRecord = {
      messageId: record.messageId,
      audioHash: record.audioHash,
      transcript: record.transcript,
      language: record.language,
      status: record.status,
      modelVersion: record.modelVersion,
      processedAt: record.processedAt,
      durationSec: record.durationSec,
      inferenceDevice: record.inferenceDevice
    };
    this.data.byMessageId[cleanRecord.messageId] = cleanRecord;
    if (cleanRecord.audioHash) {
      this.data.byAudioHash[cleanRecord.audioHash] = cleanRecord.messageId;
    }
    this.evictOldestIfNeeded();
    await this.persist();
  }
  async deleteByMessageId(messageId) {
    await this.ensureLoaded();
    const existing = this.data.byMessageId[messageId];
    if (existing?.audioHash && this.data.byAudioHash[existing.audioHash] === messageId) {
      delete this.data.byAudioHash[existing.audioHash];
    }
    delete this.data.byMessageId[messageId];
    await this.persist();
  }
  async clearAll() {
    this.data = { version: 1, byMessageId: {}, byAudioHash: {} };
    this.loaded = true;
    await this.storage.removeItem(CACHE_STORAGE_KEY);
  }
  async count() {
    await this.ensureLoaded();
    return Object.keys(this.data.byMessageId).length;
  }
  async listAll() {
    await this.ensureLoaded();
    return Object.values(this.data.byMessageId).sort(
      (a, b) => b.processedAt.localeCompare(a.processedAt)
    );
  }
  evictOldestIfNeeded() {
    const entries = Object.entries(this.data.byMessageId);
    if (entries.length <= MAX_CACHED_RECORDS) return;
    entries.sort((a, b) => a[1].processedAt.localeCompare(b[1].processedAt));
    const toRemove = entries.length - MAX_CACHED_RECORDS;
    for (let i = 0; i < toRemove; i++) {
      const [msgId, rec] = entries[i];
      delete this.data.byMessageId[msgId];
      if (rec.audioHash && this.data.byAudioHash[rec.audioHash] === msgId) {
        delete this.data.byAudioHash[rec.audioHash];
      }
    }
  }
  async persist() {
    await this.storage.setItem(CACHE_STORAGE_KEY, JSON.stringify(this.data));
  }
};

// extension/src/shared/types.ts
var DEFAULT_EXTENSION_SETTINGS = {
  serverUrl: "http://127.0.0.1:8765",
  authToken: "",
  language: "auto",
  autoTranscribe: true,
  showTranscriptExpandedByDefault: true,
  enableGitHubUpdateCheck: true,
  githubRepo: "Kompetenz-Nord/TransWA"
};
var WHISPER_MODEL_ID = "Systran/faster-whisper-small";

// extension/src/shared/update-checker.ts
function normalizeSemver(version) {
  const cleaned = version.trim().replace(/^v/i, "").split("-")[0];
  const parts = cleaned.split(".").map((n) => {
    const parsed = Number.parseInt(n, 10);
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : 0;
  });
  return [parts[0] ?? 0, parts[1] ?? 0, parts[2] ?? 0];
}
function isNewerVersion(currentVersion, candidateVersion) {
  const cur = normalizeSemver(currentVersion);
  const cand = normalizeSemver(candidateVersion);
  for (let i = 0; i < 3; i++) {
    if (cand[i] > cur[i]) return true;
    if (cand[i] < cur[i]) return false;
  }
  return false;
}
async function checkGitHubReleaseUpdate(params) {
  const checkedAt = (/* @__PURE__ */ new Date()).toISOString();
  const repo = params.githubRepo.trim();
  if (!/^[a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+$/.test(repo)) {
    return {
      checkedAt,
      currentVersion: params.currentVersion,
      latestVersion: null,
      updateAvailable: false,
      releaseUrl: null,
      error: "Ung\xFCltiger Repository-Bezeichner."
    };
  }
  const doFetch = params.fetchImpl ?? fetch;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5e3);
    const response = await doFetch(`https://api.github.com/repos/${repo}/releases/latest`, {
      method: "GET",
      headers: { Accept: "application/vnd.github+json" },
      signal: controller.signal
    });
    clearTimeout(timer);
    if (!response.ok) {
      return {
        checkedAt,
        currentVersion: params.currentVersion,
        latestVersion: null,
        updateAvailable: false,
        releaseUrl: null,
        error: `GitHub API HTTP ${response.status}`
      };
    }
    const payload = await response.json();
    const tagName = typeof payload.tag_name === "string" ? payload.tag_name : null;
    const htmlUrl = typeof payload.html_url === "string" ? payload.html_url : null;
    if (!tagName) {
      return {
        checkedAt,
        currentVersion: params.currentVersion,
        latestVersion: null,
        updateAvailable: false,
        releaseUrl: htmlUrl,
        error: "Keine Versionsnummer im Release gefunden."
      };
    }
    return {
      checkedAt,
      currentVersion: params.currentVersion,
      latestVersion: tagName.replace(/^v/i, ""),
      updateAvailable: isNewerVersion(params.currentVersion, tagName),
      releaseUrl: htmlUrl,
      error: null
    };
  } catch (err) {
    return {
      checkedAt,
      currentVersion: params.currentVersion,
      latestVersion: null,
      updateAvailable: false,
      releaseUrl: null,
      error: err instanceof Error ? err.message : "Versionspr\xFCfung fehlgeschlagen"
    };
  }
}

// extension/src/background/service-worker.ts
var SETTINGS_KEY = "wa_local_ai_settings_v1";
var DIAGNOSTICS_KEY = "wa_local_ai_last_diagnostics_v1";
var UPDATE_CHECK_KEY = "wa_local_ai_last_update_check_v1";
var cache = new LocalTranscriptCache(new ChromeStorageAdapter());
function assertStrictLoopbackServerUrl(rawUrl) {
  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    throw new Error("Ung\xFCltige lokale Server-URL.");
  }
  if (parsed.protocol !== "http:") {
    throw new Error("Lokaler Whisper-Server muss \xFCber http://127.0.0.1 angesprochen werden.");
  }
  if (parsed.hostname !== "127.0.0.1" && parsed.hostname !== "localhost") {
    throw new Error(
      `Sicherheitsblockade: Externe Server (${parsed.hostname}) sind strikt verboten. Nur 127.0.0.1 zul\xE4ssig.`
    );
  }
  return parsed.origin;
}
async function loadSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  const raw = stored[SETTINGS_KEY];
  return {
    ...DEFAULT_EXTENSION_SETTINGS,
    ...raw ?? {}
  };
}
async function saveSettings(next) {
  const safeOrigin = assertStrictLoopbackServerUrl(next.serverUrl);
  const sanitized = {
    ...DEFAULT_EXTENSION_SETTINGS,
    ...next,
    serverUrl: safeOrigin
  };
  await chrome.storage.local.set({ [SETTINGS_KEY]: sanitized });
  return sanitized;
}
async function fetchBackendHealth(settings) {
  try {
    const baseUrl = assertStrictLoopbackServerUrl(settings.serverUrl);
    const headers = {};
    if (settings.authToken) {
      headers["X-Transcriber-Token"] = settings.authToken;
    }
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 3e3);
    const res = await fetch(`${baseUrl}/health`, {
      method: "GET",
      headers,
      signal: controller.signal
    });
    clearTimeout(timer);
    if (res.status === 401 || res.status === 403) {
      return {
        reachable: true,
        status: "unauthorized",
        model: WHISPER_MODEL_ID,
        device: "unknown",
        computeType: "unknown",
        cudaAvailable: false,
        gpuName: null,
        version: null,
        error: "Client-Authentifizierung fehlgeschlagen (Token pr\xFCfen)."
      };
    }
    if (!res.ok) {
      return {
        reachable: true,
        status: "degraded",
        model: WHISPER_MODEL_ID,
        device: "unknown",
        computeType: "unknown",
        cudaAvailable: false,
        gpuName: null,
        version: null,
        error: `HTTP ${res.status}`
      };
    }
    const data = await res.json();
    return {
      reachable: true,
      status: data.status === "ok" ? "ok" : "degraded",
      model: data.model ?? WHISPER_MODEL_ID,
      device: data.device ?? "cpu",
      computeType: data.compute_type ?? "int8",
      cudaAvailable: Boolean(data.cuda_available),
      gpuName: data.gpu_name ?? null,
      version: data.version ?? null,
      error: null
    };
  } catch (err) {
    return {
      reachable: false,
      status: "offline",
      model: WHISPER_MODEL_ID,
      device: "offline",
      computeType: "offline",
      cudaAvailable: false,
      gpuName: null,
      version: null,
      error: err instanceof Error ? `Lokaler Whisper-Server (127.0.0.1:8765) nicht erreichbar: ${err.message}` : "Lokaler Whisper-Server offline."
    };
  }
}
async function transcribeWithLocalWhisper(payload) {
  const settings = await loadSettings();
  const baseUrl = assertStrictLoopbackServerUrl(settings.serverUrl);
  if (!settings.authToken.trim()) {
    return {
      ok: false,
      error: "Lokales Server-Token fehlt. Bitte Token aus dem Windows-Setup in den Erweiterungs-Optionen hinterlegen."
    };
  }
  if (!payload?.audioBase64 || typeof payload.audioBase64 !== "string") {
    return { ok: false, error: "Ung\xFCltige Audiodaten empfangen." };
  }
  let rawBinary;
  try {
    rawBinary = atob(payload.audioBase64);
  } catch {
    return { ok: false, error: "Base64-Audiodaten konnten nicht dekodiert werden." };
  }
  const bytes = new Uint8Array(rawBinary.length);
  for (let i = 0; i < rawBinary.length; i++) {
    bytes[i] = rawBinary.charCodeAt(i);
  }
  const formData = new FormData();
  const blob = new Blob([bytes], { type: payload.mimetype || "audio/ogg" });
  formData.append("audio", blob, "voice_message.ogg");
  formData.append("audio_sha256", payload.audioHash);
  formData.append("language", settings.language);
  const response = await fetch(`${baseUrl}/transcribe`, {
    method: "POST",
    headers: {
      "X-Transcriber-Token": settings.authToken.trim()
    },
    body: formData
  });
  if (response.status === 401 || response.status === 403) {
    return {
      ok: false,
      error: "Zugriff vom lokalen Whisper-Server verweigert (Token oder Origin ung\xFCltig)."
    };
  }
  if (!response.ok) {
    const errText = await response.text().catch(() => "");
    return {
      ok: false,
      error: `Whisper-Server Fehler (${response.status}): ${errText || "Unbekannt"}`
    };
  }
  const result = await response.json();
  return {
    ok: true,
    transcript: result.transcript,
    language: result.language,
    inferenceDevice: `${result.device}/${result.compute_type}`,
    modelVersion: result.model || WHISPER_MODEL_ID
  };
}
chrome.runtime.onInstalled.addListener(() => {
  void loadSettings().then((settings) => saveSettings(settings));
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender?.id !== chrome.runtime.id) {
    return false;
  }
  const msg = message;
  if (msg.type === "GET_SETTINGS") {
    void loadSettings().then((settings) => sendResponse({ settings }));
    return true;
  }
  if (msg.type === "SAVE_SETTINGS") {
    void saveSettings(msg.settings).then((settings) => sendResponse({ ok: true, settings })).catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  if (msg.type === "TRANSCRIBE_AUDIO") {
    void transcribeWithLocalWhisper(
      msg.payload
    ).then((res) => sendResponse(res)).catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
  if (msg.type === "CHECK_HEALTH") {
    void loadSettings().then((settings) => fetchBackendHealth(settings)).then((health) => sendResponse({ health }));
    return true;
  }
  if (msg.type === "UPDATE_ADAPTER_DIAGNOSTICS") {
    const report = msg.report;
    void chrome.storage.local.set({ [DIAGNOSTICS_KEY]: report });
    sendResponse({ ok: true });
    return false;
  }
  if (msg.type === "GET_STATUS_SUMMARY") {
    void (async () => {
      const settings = await loadSettings();
      const [health, cacheCount, storedState] = await Promise.all([
        fetchBackendHealth(settings),
        cache.count(),
        chrome.storage.local.get([DIAGNOSTICS_KEY, UPDATE_CHECK_KEY])
      ]);
      let updateResult = storedState[UPDATE_CHECK_KEY];
      if (settings.enableGitHubUpdateCheck && !updateResult) {
        const manifestVersion = chrome.runtime.getManifest().version;
        updateResult = await checkGitHubReleaseUpdate({
          currentVersion: manifestVersion,
          githubRepo: settings.githubRepo
        });
        await chrome.storage.local.set({ [UPDATE_CHECK_KEY]: updateResult });
      }
      sendResponse({
        settings,
        health,
        cacheCount,
        diagnostics: storedState[DIAGNOSTICS_KEY] ?? null,
        updateCheck: updateResult ?? null
      });
    })();
    return true;
  }
  if (msg.type === "CHECK_GITHUB_UPDATE") {
    void (async () => {
      const settings = await loadSettings();
      const manifestVersion = chrome.runtime.getManifest().version;
      const updateResult = await checkGitHubReleaseUpdate({
        currentVersion: manifestVersion,
        githubRepo: settings.githubRepo
      });
      await chrome.storage.local.set({ [UPDATE_CHECK_KEY]: updateResult });
      sendResponse({ updateCheck: updateResult });
    })();
    return true;
  }
  if (msg.type === "CLEAR_CACHE") {
    void cache.clearAll().then(() => sendResponse({ ok: true }));
    return true;
  }
  return false;
});
export {
  assertStrictLoopbackServerUrl
};
